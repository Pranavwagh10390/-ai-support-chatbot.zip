**User:** What pricing plans do you offer?
**Bot:** We offer Free, Pro ($15/user/mo), and Enterprise plans.
