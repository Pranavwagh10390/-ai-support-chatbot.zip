# API Reference

Base URL: `https://api.flowly.io`

Authentication via API key.