# Onboarding Guide

1. Sign up
2. Create workspace
3. Invite team