# Technical Support FAQs

**Q:** How do I reset my password?
**A:** Click 'Forgot Password' at login.