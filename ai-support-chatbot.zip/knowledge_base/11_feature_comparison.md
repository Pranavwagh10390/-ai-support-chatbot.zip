# Feature Comparison

| Plan | Automation | Integrations |
|------|------------|--------------|
| Free | Basic      | Limited      |