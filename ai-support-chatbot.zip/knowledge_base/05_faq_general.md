# General FAQs

**Q:** What is Flowly?
**A:** A project management automation SaaS tool.