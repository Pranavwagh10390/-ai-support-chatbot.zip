# Use Case: Marketing Team

Flowly helps marketing teams plan and automate campaign tasks.