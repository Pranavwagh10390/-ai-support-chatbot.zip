# Privacy Policy

We respect your privacy and never share your data.