# Security & Compliance

Flowly is GDPR and SOC2 compliant.