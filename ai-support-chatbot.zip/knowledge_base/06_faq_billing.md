# Billing FAQs

**Q:** How do I change my plan?
**A:** Go to Account > Billing.