# Pricing Tiers

- Free
- Pro: $15/user/mo
- Enterprise: Custom pricing